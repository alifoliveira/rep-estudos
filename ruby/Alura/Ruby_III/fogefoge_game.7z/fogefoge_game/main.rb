require_relative 'fogefoge'

inicia_jogo()
